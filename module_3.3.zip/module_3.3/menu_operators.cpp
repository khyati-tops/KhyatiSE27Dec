//WAP to show a menu of different operators and ask the user to input two numbers to perform an operation

#include<stdio.h>

int add(int x,int y)
{
	printf("Addition of the %d and %d is %d",x,y,x+y);
}
int sub(int x,int y)
{
	printf("Subtraction of the %d and %d is %d",x,y,x-y);
}
int mult(int x,int y)
{
	printf("Product of the %d and %d is %d",x,y,x*y);
}
int div(int x,int y)
{
	if(y==0)
	{
		printf("as the second number is zero, calculation cant be performed");
	}
	else
	{
		printf("Quotient of the %d and %d is %d",x,y,x/y);
	}
	
}
int mod(int x,int y)
{
	if(y==0)
	{
		printf("as the second number is zero, calculation cant be performed");
	}
	else
	{
		printf("Remainder of the %d and %d is %d",x,y,x%y);
	}
}

int main()
{
	
	int oper,a,b;
	
	printf("enter two numbers:");
	scanf("%d %d",&a,&b);
	printf("\nThese are the following operators\n");
	
	printf("-------------------MENU-----------------\n");
	printf("SR.NO.        ITEM            \n");
	printf("  1           multiply\n");
	printf("  2           add\n");
	printf("  3           subtract\n");	
	printf("  4           division\n");
	printf("  5           modulo \n\n\n");	
	
	printf("Select an operator:");
	scanf("%d",&oper);
	
	if(oper==1)
	{
		mult(a,b);
	}
	else if(oper==2)
	{
		add(a,b);
	}
	else if(oper==3)
	{
		sub(a,b);
	}
	else if(oper==4)
	{
		div(a,b);
	}
	else if(oper==5)
	{
		mod(a,b);
	}
	else 
	{
		printf("\ninvalid number.");
	}
	
	return 0;
}

