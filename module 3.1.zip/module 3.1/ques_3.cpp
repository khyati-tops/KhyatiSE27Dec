//WAP to find area of circle, rectangle and triangle
#include<stdio.h>
int main()
{
	float r,length,breadth,height,base,ans;
	
	printf("Enter the radius of the circle:");
	scanf("%f",&r);
	
	printf("enter the length of the rectangle:");
	scanf("%f",&length);
	printf("enter the breadth of the recatangle:");
	scanf("%f",&breadth);
	
	printf("enter the height of the triangle:");
	scanf("%f",&height);
	printf("enter the base of the triangle:");
	scanf("%f",&base);
	
	printf("-----------------------------------");
	printf("\nThe area of:");
	
	ans=3.14*r*r;
	printf("\nCircle: %.2f",ans);
	
	ans=length*breadth;
	printf("\nRectangle: %.2f",ans);
	
	ans=0.5*height*base;
	printf("\nTriangle: %.2f",ans);
	
	return 0;
}
