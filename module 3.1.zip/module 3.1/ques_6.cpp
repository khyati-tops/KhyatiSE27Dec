//WAP to convert years into days and days into years
#include<stdio.h>
int main()
{
	float yrs,days;
	
	printf("enter no. of years:");
	scanf("%f",&yrs);
	
	days=yrs*365; //taking one year has 365 days
	printf("There are %.2f days in %.2f years",days,yrs);
	
	printf("\n\nenter no. of days:");
	scanf("%f",&days);
	
	yrs=days/365;
	printf("there are %.2f yrs in %.2f days.",yrs,days);
	
	return 0;
}
