//display this information using printf
/*
	name
	birth date
	age
	address

*/

#include<stdio.h>
int main()
{
	char name[15],add[50];
	int age,date,month,year;
	
	printf("Enter your name:");
	scanf("%s",&name);
	printf("Enter your birth day , month and year:");
	scanf("%d %d %d",&date,&month,&year);
	printf("Enter your age:");
	scanf("%d",&age);
	printf("Enter your address:");
	scanf("%s",&add);
	
	printf("\n-----------------------------");
	printf("\nYour details");
	printf("\nYour name: %s",name);
	printf("\nYour Birth Day: %d/%d/%d",date,month,year);
	printf("\nYour Age: %d",age);
	printf("\nYour Address: %s",add);
	
	return 0;
}
