//WAP to create a calculator performing addition, subtraction, multiplication and division and modulo

#include<stdio.h>

int main()
{
	int a,b;
	float result;
	
	printf("Enter two numbers:");
	scanf("%d %d",&a,&b);
	
	result=a+b;
	printf("\nAddition: %.0f",result);
	
	result=a-b;
	printf("\nSubtaction: %.0f",result);
	
	result=a*b;
	printf("\nMultiplication: %.0f",result);
	
	result=a/b;
	printf("\nDivision: %.2f",result);
	
	result=a%b;
	printf("\nRemainder: %.0f",result);
	

	return 0;
}
