//WAP to find simple interest

#include<stdio.h>

int main()
{
	float rate,prin,time,si,amount;
	
	printf("enter the principal amount:");
	scanf("%f",&prin);
	printf("enter the rate per year:");
	scanf("%f",&rate);
	printf("enter the time in years:");
	scanf("%f",&time);
	
	si=(prin*rate*time)/100;
	amount=prin+si;
	
	printf("Simple Interest: %.2f",si);
	printf("\nThe total amount to be paid with interest: %.2f",amount);
	
	return 0;
}
