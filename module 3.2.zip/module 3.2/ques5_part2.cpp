//WAP to take 10 nos input from user to find out 
/* 1. how many even numbers are there
	2. how many odd numbers are there
	3. sum of even numbers
	4. sum of odd numbers
*/

#include<stdio.h>

int main()
{
	int i,num,even=0,odd=0,sum_even=0,sum_odd=0;
	
	for(i=1;i<=10;i++)
	{
		printf("enter a number:");
		scanf("%d",&num);
		
		if(num%2==0)
		{
			even+=1;
			sum_even=sum_even+num;
		}
		else
		{
			odd+=1;
			sum_odd=sum_odd+num;
		}
	}
	printf("-------*---------*----------*-----------*-----------*-----------*-----\n");
	printf("\nThe toal no. of even numbers are: %d",even);
	printf("\nThe total of all the even nos. are: %d",sum_even);
	
	printf("\nThe toal no. of odd numbers are: %d",odd);
	printf("\nThe total of all the odd nos. are: %d",sum_odd);
	
	return 0;
}
