//WAP to show two numbers without using third variable
#include<stdio.h>

int main()
{
	int a,b;
	printf("enter the values of two numbers:");
	scanf("%d %d",&a,&b);
	
	printf("value of A before swapping %d",a);
	printf("\nvalue of B before swapping %d",b);	
	
	a=a+b;
	b=a-b; 
	a=a-b;
	
	printf("\nvalue of A after swapping %d",a);
	printf("\nvalue of B after swapping %d",b);
	
	return 0;
	
}
	
