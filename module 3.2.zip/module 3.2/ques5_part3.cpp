// WAP to print table up to given numbers
#include<stdio.h>
int main()
{
	int i,num;
	
	printf("enter a number:");
	scanf("%d",&num);
	
	printf("\n*********Table of %d*********\n\n",num);
	
	for(i=1;i<=10;i++)
	{
		printf("\t%d * %d = %d\n",num,i,num*i);
		
	}
	
	return 0;
}
