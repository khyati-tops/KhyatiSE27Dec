//WAP to print fibonacci series
#include<stdio.h>

int main()
{
	int num,term,term1,term2,term3;
	
	term1=0;
	term2=1;
	term3=term1+term2;
	/*
		term3=term1+term2
		term4=term3+term2
		term5=term4+term3
		term6=term5+term4
	*/
	
	printf("enter the lenght of fibonacci series:");
	scanf("%d",&num);
	num=num-3;
	printf("\n-----------Fibonacci series-----------");
	printf("\n 0 1 1");
	
	while(num!=0)
	{
		//0 1 1 2 3 5 8 
		term=term2+term3;
		
		printf(" %d",term);
		term2=term3;
		term3=term;
		num--;
		
	}
	
	
	
	return 0;
}
