//WAP to determine if the number is prime or not

#include<stdio.h>
int main()
{
	int i,j=0,k,num;
	
	printf("enter a number:");
	scanf("%d",&num);
	
	if(num==0 || num==1 || num==2)
	{
		printf("number is not prime");
	}
	
	else
	{
		for(i=2;i<=num/2;i++)
		{
			if(num%i==0)
			{
				j=1;
			}
		
		}
		
		if(j==0)
		{
			printf("the number is prime");	
		}
	
		else
		{
			printf("the number is NOT prime.");
		}	
	}
	
	
	return 0;
}
