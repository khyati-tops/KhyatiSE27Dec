//WAP to print in reverse order

#include<stdio.h>
int main()
{
	int num,i,rem;
	
	printf("enter a number:");
	scanf("%d",&num);
	
	while(num!=0)
	{
		rem=num%10;
		num=num/10;
		printf("%d",rem);
	}
	
	
	
	
	return 0;
}
