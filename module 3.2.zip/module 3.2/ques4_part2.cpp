//WAP to show vowel or consonant using swithc case
#include<stdio.h>
int main()
{
	char ch;
	printf("enter an alphabet:");
	scanf("%c",&ch);
	
	
	switch(ch)
	{
		
		case 'a':
			printf("your alphabet is a vowel");
			break;
		case 'e':
			printf("your alphabet is a vowel");
			break;
		case 'i':
			printf("your alphabet is a vowel");
			break;
		case 'o':
			printf("your alphabet is a vowel");
			break;
		case 'u':
			printf("your alphabet is a vowel");
			break;
		case 'A':
			case 'E':
				case 'I':
					case 'O':
						case 'U':
							printf("vowel");
							break;
							
		default:
			printf("your alphabet is a not a vowel");
			break;	
		
	}
	
	return 0;
	
}
