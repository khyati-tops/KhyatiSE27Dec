//WAP to print factorial of given number

#include<stdio.h>
int main()
{
	int i,num,fac=1;
	
	printf("enter a number:");
	scanf("%d",&num);
	
	if(num!=0 && num>0)
	{
		for(i=1;i<=num;i++)
			{
				fac=fac*i;
			}
		printf("the factorial is %d",fac);
	
	}
	
	else if(num==0)
	{
		printf("factorial is 1");
	}
	
	else
	{
		printf("Invalid.");
	}
	
	return 0;
	
}
